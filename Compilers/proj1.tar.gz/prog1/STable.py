from STE import *

'''
This is an implementation of a Sybmol Table using a dict. This class inherits
    all methods and properties from dict. This class has been designed to be
    used with a Symbol Table Stack for lexical / syntactical analyzer.
'''

class symbolTable(dict):

    def addSymbol(self, STE):

        ## Add a Symbol Table Entry to self

        ## PRECONDITIONS: User must provide a valid STE

        ## POSTCONDITIONS: Symbol is added to the table
    
        if self.findSymbol(STE.lexeme) == False:
            
            if self.hashMethod(STE) not in self.keys():
                
                self[self.hashMethod(STE)] = STE
                return
        key = self.hashMethod(STE)
        while key in self.keys():
            key = self.hashMethod(STE, key)
        self[key] = STE
            
    def findSymbol(self, lexeme):

        ## Search for a STE in self

        ## PRECONDITIONS: A valid Symbol Table

        ## POSTCONDITIONS: Returns True if found, False otherwise
        
        for item in self:
            if self[item].lexeme == lexeme:
                return True
        return False

    def printTable(self):

        ## Test Method intended to print to screen all the elements of self

        for item in self:
            print(self[item].lexeme, self[item].ident, self[item].position)

        print(self.keys())

    def hashMethod(self, STE, hashKey = 0):

        ## Helper Method to hash a lexeme prior to insertion.

        ## PRECONDITIONS: A valid Symbol Table Entry, and an optional
        ##                int to rehash a STE in case of collision. 
        for letter in STE.lexeme:
            hashKey += ord(letter)

        return hashKey / 101
